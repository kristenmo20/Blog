<?php

class Blog extends Controller {
    function Read() {
        
    }
}


?>